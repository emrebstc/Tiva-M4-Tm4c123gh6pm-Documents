#include"inc/tm4c123gh6pm.h"

#include "lcd.h"

int main(void)
{
   lcdilkayarlar();
   lcdgotoxy(1, 1); //80h
   lcdyaz('A');

   lcdgotoxy(1, 2); //81h
   lcdyaz(0x42);

	return 0;
}
