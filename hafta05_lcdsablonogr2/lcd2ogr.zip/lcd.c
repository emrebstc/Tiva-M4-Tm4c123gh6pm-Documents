#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/gpio.c"
#include "inc/hw_gpio.h"
#include "driverlib/sysctl.c"

#include "lcd.h"

void otuzhexgonder()
{
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, rs, 0); // rs=0
    GPIOPinWrite(LCDPORT, d4|d5|d6|d7, 0x30);
    GPIOPinWrite(LCDPORT, E, 2); // rs=0
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, E, 0); // rs=0
}

void lcdilkayarlar(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB); // portb aktif
    GPIOPinTypeGPIOOutput(LCDPORT, 0xFF); // butun pinler output

    otuzhexgonder();
    otuzhexgonder();
    otuzhexgonder();

    // dl=0 4 bit
    //lcdfonksiyonayarla(4,2,)

    LcdKomut(0x0f); // ekran a� kapat
    // ekran sil kursor ba�a d�n
    // giri� kipini belirle
}

void LcdKomut (unsigned char c)
{
    GPIOPinWrite(LCDPORT, rs, 0); // rs=0
    GPIOPinWrite(LCDPORT, d4|d5|d6|d7, (c & 0xF0));
    GPIOPinWrite(LCDPORT, E, 2); // rs=0
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, E, 0); // rs=0

    SysCtlDelay(2000);

    GPIOPinWrite(LCDPORT, rs, 0); // rs=0
    GPIOPinWrite(LCDPORT, d4|d5|d6|d7, (c & 0x0F)<<4);
    GPIOPinWrite(LCDPORT, E, 2); // rs=0
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, E, 0); // rs=0


}

void LcdTemizle(void)
{
    LcdKomut(0x01);
}

void lcdfonksiyonayarla( unsigned char dl,unsigned char N,unsigned char F) // dl,N,F
{
    // dl i�in ya 4 yada 8
    // N i�in 1 i�in 1 sat�ra, 2 gelirse 2 sat�r
    // F i�in 7 gelise 5x7 fontu
       // e�er 10 gelirse de 5x10 fonutunu
}


void lcdyaz(unsigned char c)
{
    GPIOPinWrite(LCDPORT, rs, 1); // rs=0
    GPIOPinWrite(LCDPORT, d4|d5|d6|d7, (c & 0xF0));
    GPIOPinWrite(LCDPORT, E, 2); // rs=0
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, E, 0); // rs=0

    SysCtlDelay(2000);

    GPIOPinWrite(LCDPORT, rs, 1); // rs=0
    GPIOPinWrite(LCDPORT, d4|d5|d6|d7, (c & 0x0F)<<4);
    GPIOPinWrite(LCDPORT, E, 2); // rs=0
    SysCtlDelay(2000);
    GPIOPinWrite(LCDPORT, E, 0); // rs=0

}

void lcdgotoxy(unsigned char x, unsigned char y)
{
    // x=1 y=5 derse 84h olacak kodu
    // rs=0
}
