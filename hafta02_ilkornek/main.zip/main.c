#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h" // general purposes input output
#include "driverlib/gpio.c"
#include "inc/hw_memmap.h"

// global de�i�kenler

float a;

// fonksiyon deklarasyon;

void main(void)
{
    SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN); // bitsel or
    uint32_t saat= SysCtlClockGet();
    // de�i�kenlerimiz
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF); // �evre birimi aktif

    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2);
    // ayar bitti

    while(1)
    {
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2, 2);
        //0000 0xy0
        //0000 0010

        SysCtlDelay(20000000);

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2, 4);
        SysCtlDelay(20000000);

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2, 0);
        SysCtlDelay(20000000);

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2, 6);
        SysCtlDelay(20000000);
    }
}


